#!/usr/bin/env python3
"""Воспроизведение и проверка ошибок, найденных в NetMon 1.4.

Каждый тест проверяет корректное (ожидаемое) поведение. На неисправленном
NetMon 1.4 все эти тесты падают (FAIL), наглядно демонстрируя соответствующую ошибку.

Запуск:
    python3 test_netmon_1_4_bugs.py
"""

import argparse
import contextlib
import io
import os
import socket
import struct
import sys
import unittest
from unittest import mock

# Автоматический поиск папки netmon (рядом со скриптом или внутри распакованного архива)
HERE = os.path.dirname(os.path.abspath(__file__))
for candidate in (
    HERE,
    os.path.join(HERE, 'netmon'),
    os.path.join(HERE, 'Lab-claude-exciting-rubin-7ydofi', 'netmon'),
    os.path.join(HERE, 'netmon_src', 'Lab-claude-exciting-rubin-7ydofi', 'netmon'),
):
    if os.path.isfile(os.path.join(candidate, 'model.py')):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
        break

import console  # noqa: E402
import etw  # noqa: E402
import firewall  # noqa: E402
from etw import Prop, decode_payload  # noqa: E402
from firewall import (  # noqa: E402
    DemoFirewall,
    FirewallError,
    FirewallManager,
    block_plan,
    check_blockable,
)
from model import Model, group_views  # noqa: E402
from storage import Storage  # noqa: E402

LOCAL = '192.168.1.5'
SVCHOST = r'C:\Windows\System32\svchost.exe'
EXPLORER = r'C:\Windows\explorer.exe'


def v4(ip):
    return socket.inet_aton(ip)


def port(n):
    return n.to_bytes(2, 'big')


def send_tcp(model, pid, remote, rport, lport, sent, ts, local=LOCAL):
    model.on_traffic(pid, 'TCP', True, sent, v4(remote), port(rport), v4(local), port(lport), ts)


class Bug01LateStartMergedIntoNewerInstanceTest(unittest.TestCase):
    """Ошибка 1 (model.py: _started_instance / _late_start):
    Запоздавшее событие on_process_start прежнего владельца PID сливается
    с записью НОВОГО владельца того же PID (созданной по трафику или снимку),
    подменяет ей имя/путь/время запуска и обрезает время завершения старой записи.
    """

    def test_late_start_of_first_instance_does_not_corrupt_second_instance(self):
        m = Model()
        m.resolve_names = False
        # 1-й владелец PID 100 (old.exe) отправил пакет в 1.0 и завершился в 2.0
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=10, ts=1.0)
        m.on_process_stop(100, 2.0)
        # 2-й владелец PID 100 (new.exe) отправил пакет в 5.0 (до прихода своего start)
        send_tcp(m, 100, '1.1.1.1', 443, 50001, sent=20, ts=5.0)
        # Приходит запоздавший on_process_start 1-го процесса (ts=0.9), а затем 2-го (ts=4.9)
        m.on_process_start(100, 0.9, r'C:\old.exe')
        m.on_process_start(100, 4.9, r'C:\new.exe')
        m.process_pending()

        procs = sorted(m.procs.values(), key=lambda p: p.uid)
        self.assertEqual(len(procs), 2, 'Должно быть ровно 2 экземпляра процесса, а не 3')
        old, new = procs
        self.assertEqual((old.name, old.started, old.ended, old.sent), ('old.exe', 0.9, 2.0, 10))
        self.assertEqual((new.name, new.started, new.ended, new.sent), ('new.exe', 4.9, None, 20))


class Bug02ExeMismatchAndUnstartedCurInApplyStartTest(unittest.TestCase):
    """Ошибка 2 (model.py: _late_start / _apply_start):
    2A. _late_start не сверяет имя/путь exe из события on_process_start с уже известным
        snap_name или path записи, из-за чего запуск old.exe перезаписывает имя и путь new.exe.
    2B. Если у текущего процесса cur ещё нет cur.started (создан по снимку или трафику),
        запоздавший on_process_start давнего владельца PID (из прошлого) не отбрасывается,
        а завершает работающий cur временем из прошлого и подменяет by_pid[pid].
    """

    def test_late_start_with_different_exe_name_does_not_overwrite_snapshot_process(self):
        m = Model()
        m.resolve_names = False
        # Снимок в 5.0 увидел уже новый процесс new.exe на PID 100
        m.sync_processes({100: ('new.exe', 1)}, now=5.0)
        # Приходит запоздавший запуск прежнего владельца PID 100 (old.exe, ts=4.5)
        m.on_process_start(100, 4.5, r'C:\old.exe')
        m.process_pending()

        cur = m.by_pid[100]
        self.assertEqual(cur.name, 'new.exe', 'Текущий процесс new.exe не должен превращаться в old.exe')
        self.assertNotEqual(cur.path, r'C:\old.exe')
        self.assertIsNone(cur.ended)

    def test_ancient_start_does_not_terminate_current_process_without_started_time(self):
        m = Model()
        m.resolve_names = False
        # old1 отработал 1.0..2.0
        m.on_process_start(100, 1.0, r'C:\old1.exe')
        m.on_process_stop(100, 2.0)
        m.process_pending()
        # В 5.0 снимок увидел new.exe (started ещё None, т.к. fill_details ещё не вызывался)
        m.sync_processes({100: ('new.exe', 1)}, now=5.0)
        # Приходит сильно задержавшийся on_process_start процесса, жившего ещё до old1 (ts=0.5)
        m.on_process_start(100, 0.5, r'C:\ancient.exe')
        m.process_pending()

        cur = m.by_pid[100]
        self.assertEqual(cur.name, 'new.exe')
        self.assertIsNone(cur.ended, 'Работающий new.exe не должен завершаться событием из прошлого')


class Bug03LateStopEndsNewProcessWithinSlackTest(unittest.TestCase):
    """Ошибка 3 (model.py: _apply_stop):
    Если после выхода old.exe (ts=100.01) его PID быстро достался new.exe и попал
    в снимок процессов в пределах SLACK (0.25 с, например now=100.05), а событие
    ETW on_process_stop(100, 100.01) дошло после снимка, _apply_stop ошибочно
    завершает НОВЫЙ работающий процесс new.exe вместо уточнения времени old.exe.
    """

    def test_delayed_stop_within_slack_does_not_kill_new_owner(self):
        m = Model()
        m.resolve_names = False
        m.on_process_start(100, 90.0, r'C:\old.exe')
        m.process_pending()
        # Снимок в 100.05 уже видит new.exe на PID 100
        m.sync_processes({100: ('new.exe', 1)}, now=100.05)
        # Доходит событие остановки old.exe в 100.01 (разница 0.04 с < SLACK=0.25 с)
        m.on_process_stop(100, 100.01)
        m.process_pending()

        by_name = {p.name: p for p in m.procs.values()}
        self.assertEqual(by_name['old.exe'].ended, 100.01)
        self.assertIsNone(by_name['new.exe'].ended, 'new.exe работает и не должен быть завершён')
        self.assertTrue(
            any(pid == 100 for _uid, pid in m.pending_details()),
            'Для работающего new.exe должны запрашиваться подробности (pending_details)',
        )


class Bug04TrafficAndLifecycleBatchOrderingTest(unittest.TestCase):
    """Ошибка 4 (model.py: on_traffic / _push / process_pending):
    4A. В on_traffic при приходе пакетов одного потока не по порядку a[5] (t1)
        безусловно перезаписывается последним пришедшим ts, из-за чего t0 > t1.
    4B. Если пакеты старого (ts=10.0) и нового (ts=15.0) процесса с тем же PID
        пришли из Kernel-Network раньше, чем события stop(11.0) и start(12.0) из
        Kernel-Process в той же пачке process_pending(), весь трафик нового
        процесса приписывается старому (уже завершившемуся в 11.0).
    """

    def test_out_of_order_packets_preserve_min_first_and_max_last(self):
        m = Model()
        m.resolve_names = False
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=20, ts=20.0)
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=5, ts=5.0)  # запоздавший ранний пакет
        m.process_pending()

        ep = m.by_pid[100].endpoints[('TCP', '1.1.1.1', 443, False)]
        self.assertEqual(ep.first, 5.0, 'ep.first должен быть минимальным временем пакета (5.0)')
        self.assertEqual(ep.last, 20.0, 'ep.last должен быть максимальным временем пакета (20.0)')

    def test_traffic_arriving_before_stop_and_start_in_same_batch(self):
        m = Model()
        m.resolve_names = False
        m.on_process_start(100, 1.0, r'C:\old.exe')
        # События сети пришли из буфера Kernel-Network чуть раньше буфера Kernel-Process
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        send_tcp(m, 100, '2.2.2.2', 443, 50001, sent=25, ts=15.0)
        m.on_process_stop(100, 11.0)
        m.on_process_start(100, 12.0, r'C:\new.exe')
        m.process_pending()

        by_name = {p.name: p for p in m.procs.values()}
        self.assertEqual(by_name['old.exe'].sent, 10)
        self.assertEqual(by_name['new.exe'].sent, 25)


class Bug05SvchostWantServicesAndHistoryRestoreTest(unittest.TestCase):
    """Ошибка 5 (model.py: _want_services / load_history):
    5A. Если запись svchost.exe сначала создана по трафику (с именем 'PID N'),
        а имя 'svchost.exe' узнаётся позже в sync_processes, fill_details или
        _apply_start (ветка _started_instance), флаг _want_services не выставляется.
    5B. load_history не восстанавливает accept_ports для входящих TCP-адресатов,
        поэтому после перезапуска и _reattach новые пакеты принятого соединения
        (если слушающий сокет не в listen_table) считаются исходящими.
    """

    def test_want_services_is_set_when_svchost_name_is_discovered_later(self):
        m = Model()
        m.resolve_names = False
        send_tcp(m, 500, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        m.process_pending()
        self.assertFalse(m.want_services())
        # Теперь снимок или fill_details узнаёт, что PID 500 — это svchost.exe
        m.fill_details(m.by_pid[500].uid, {'path': SVCHOST, 'started': 9.0}, now=10.5)
        self.assertTrue(
            m.want_services(),
            'После того как стало известно имя svchost.exe, want_services() должен стать True',
        )

    def test_reattached_history_process_keeps_inbound_accept_port(self):
        m = Model()
        m.resolve_names = False
        m.sync_processes({201: ('server.exe', 1)}, now=10.0)
        m.fill_details(1, {'path': r'C:\server.exe', 'started': 5.0}, now=10.0)
        m.on_accept(201, port(9000), 10.0)
        send_tcp(m, 201, '10.0.0.8', 60000, 9000, sent=100, ts=11.0)
        m.process_pending()

        # Сохраняем и загружаем историю в новый экземпляр Model (имитация перезапуска)
        rows = [
            {
                'id': 1, 'pid': 201, 'name': 'server.exe', 'path': r'C:\server.exe',
                'cmdline': '', 'services': '', 'started': 5.0, 'ended': None,
                'first_seen': 10.0, 'last_seen': 11.0, 'sent': 100, 'recv': 0,
                'lo_sent': 0, 'lo_recv': 0,
                'endpoints': [{
                    'proc_id': 1, 'proto': 'TCP', 'ip': '10.0.0.8', 'port': 9000,
                    'inbound': 1, 'host': '', 'sent': 100, 'recv': 0,
                    'psent': 1, 'precv': 0, 'first_seen': 11.0, 'last_seen': 11.0,
                }],
            }
        ]
        m2 = Model()
        m2.resolve_names = False
        m2.load_history(rows)
        m2.sync_processes({201: ('server.exe', 1)}, now=20.0)
        m2.sync_tcp([], now=20.0)  # таблица TCP прочитана (listen_known=True), слушающий сокет закрыт
        for uid, _pid in m2.pending_details():
            m2.fill_details(uid, {'path': r'C:\server.exe', 'started': 5.0}, now=20.0)
        # Продолжается обмен по уже принятому соединению на нашем порту 9000
        send_tcp(m2, 201, '10.0.0.8', 60000, 9000, sent=50, ts=21.0)
        m2.process_pending()

        eps = m2.by_pid[201].endpoints
        self.assertEqual(
            list(eps.keys()),
            [('TCP', '10.0.0.8', 9000, True)],
            'Трафик принятого соединения не должен дробиться на ложный исходящий порт 60000',
        )


class Bug06ConsoleFirewallCliWindowsAbspathTest(unittest.TestCase):
    """Ошибка 6 (console.py: run_firewall_cli):
    В Windows (os.name == 'nt') вызов os.path.abspath(args.block) перед check_blockable:
    1) Превращает относительное имя 'explorer.exe' в 'C:\\текущая_папка\\explorer.exe',
       обходя проверку check_blockable и создавая бесполезное правило не для того файла.
    2) Ломает пути с переменными окружения вида '%SystemRoot%\\explorer.exe', приклеивая
       к ним спереди текущую папку ('C:\\текущая_папка\\%SystemRoot%\\explorer.exe').
    3) Не разбивает службы, переданные в --service через пробел.
    """

    def test_relative_path_is_rejected_on_windows_cli(self):
        fw = DemoFirewall(delay=0)
        args = argparse.Namespace(
            block='explorer.exe', unblock=None, service=[], outbound_only=False, blocked=False
        )
        out = io.StringIO()
        with mock.patch.object(console.os, 'name', 'nt'), \
                mock.patch.object(console.os.path, 'abspath', lambda p: r'C:\work\\' + p), \
                contextlib.redirect_stdout(out):
            code = console.run_firewall_cli(fw, args)

        self.assertEqual(code, 1, 'Относительный путь explorer.exe должен отклоняться и в Windows')
        self.assertEqual(fw.rules, {}, 'Правило для C:\\work\\explorer.exe не должно создаваться')


class Bug07CheckBlockableAndCleanPathTest(unittest.TestCase):
    """Ошибка 7 (firewall.py: check_blockable / block_plan):
    7A. check_blockable без pid=4 разрешает заблокировать ядро Windows
        C:\\Windows\\System32\\ntoskrnl.exe (хотя в CLI, apply_block и при ручном выборе
        файла в диалоге pid всегда равен None).
    7B. check_blockable отклоняет корректный путь с переменной окружения
        '%SystemRoot%\\System32\\svchost.exe', так как вызывает ntpath.isabs до раскрытия переменных.
    7C. block_plan передаёт в PowerShell путь с внешними кавычками или прямыми слешами '/',
        из-за чего verify_block (использующий normalize_path) считает запрет успешным,
        но фильтр WFP в Windows не совпадает с путём процесса.
    """

    def test_ntoskrnl_is_rejected_even_without_pid(self):
        err = check_blockable(r'C:\Windows\System32\ntoskrnl.exe', [], pid=None)
        self.assertIsNotNone(err, 'Блокировка ntoskrnl.exe должна запрещаться даже при pid=None')

    def test_env_var_path_is_accepted_by_check_blockable(self):
        with mock.patch.dict(os.environ, {'SystemRoot': r'C:\Windows'}):
            err = check_blockable(r'%SystemRoot%\explorer.exe', [])
            self.assertIsNone(err, 'Путь с %SystemRoot% должен приниматься check_blockable')

    def test_block_plan_cleans_quotes_and_forward_slashes(self):
        plan = block_plan('  "C:/Windows/explorer.exe"  ')
        self.assertEqual(plan[0]['program'], r'C:\Windows\explorer.exe')


class Bug08FirewallManagerServiceStatusTest(unittest.TestCase):
    """Ошибка 8 (firewall.py: FirewallManager.status):
    Для служб svchost.exe метод FirewallManager.status проверяет только `enabled is True`.
    Из-за этого:
    8A. Когда запрет службы временно выключен («Временно разрешить», enabled=False),
        в таблице процессов возвращается ('', '') вместо ('allowed', 'запрет выключен').
    8B. Когда у службы включено только одно из двух правил (enabled=None, например
        исходящее включено, а входящее выключено в wf.msc), возвращается ('', '')
        вместо ('partial', ...), скрывая действующий запрет.
    8C. Если начальное чтение правил при старте завершилось ошибкой (state_known=False,
        _index пуст), status() возвращает ('', '') вместо ('unknown', 'неизвестно').
    """

    def test_paused_and_partially_enabled_service_status(self):
        firewall.log.disabled = True
        self.addCleanup(setattr, firewall.log, 'disabled', False)
        backend = DemoFirewall(delay=0)
        m = FirewallManager(backend)
        self.addCleanup(m.shutdown)

        # Запрещаем службу BITS (входящие и исходящие), затем временно разрешаем
        m.block(SVCHOST, ['BITS']).result()
        m.set_enabled(m.entries, False).result()
        self.assertEqual(
            m.status(SVCHOST, 'BITS'),
            ('allowed', 'запрет выключен'),
            'Для временно разрешённой службы должен показываться статус "запрет выключен"',
        )

        # Включаем только исходящее правило службы BITS (частичный запрет: enabled=None)
        out_id = firewall.rule_id(SVCHOST, 'BITS', 'out')
        backend.set_enabled([out_id], True)
        m.refresh().result()
        state, _label = m.status(SVCHOST, 'BITS')
        self.assertIn(
            state,
            ('partial', 'blocked'),
            'Служба с активным исходящим запретом не должна иметь пустой статус брандмауэра',
        )

    def test_initial_read_failure_reports_unknown_status(self):
        firewall.log.disabled = True
        self.addCleanup(setattr, firewall.log, 'disabled', False)
        backend = DemoFirewall(delay=0)
        backend.state = mock.Mock(side_effect=FirewallError('Отказано в доступе'))
        m = FirewallManager(backend)
        self.addCleanup(m.shutdown)

        m.refresh().result()
        self.assertEqual(
            m.status(EXPLORER),
            ('unknown', 'неизвестно'),
            'При ошибке чтения правил статус должен быть "неизвестно", а не пустой строкой',
        )


class Bug09EtwDecodeZeroParamLengthTest(unittest.TestCase):
    """Ошибка 9 (etw.py: decode_payload / fixed_size):
    Если у поля TDH_INTYPE_BINARY, TDH_INTYPE_UNICODESTRING или TDH_INTYPE_ANSISTRING
    установлен флаг PROPERTY_PARAM_LENGTH, а значение поля-длины равно 0:
    - для BINARY fixed_size возвращает None и decode_payload обрывает разбор всего события;
    - для UNICODESTRING/ANSISTRING проверка `if length:` ложна и decode_payload читает
      до следующего нулевого байта, съедая последующие поля события.
    """

    def test_zero_param_length_binary_and_string_do_not_break_decoding(self):
        U8, U16, UNICODE, BINARY = 4, 6, 1, 14
        props = [
            Prop('BlobLen', 0, U16, 0, 1, 0),
            Prop('Blob', etw.PROPERTY_PARAM_LENGTH, BINARY, 0, 1, 0),
            Prop('StrLen', 0, U16, 0, 1, 0),
            Prop('Str', etw.PROPERTY_PARAM_LENGTH, UNICODE, 0, 1, 2),
            Prop('Tail', 0, U8, 0, 1, 0),
        ]
        data = struct.pack('<HHB', 0, 0, 42)
        fields = decode_payload(props, data, 8)
        self.assertEqual(fields.get('blob'), b'')
        self.assertEqual(fields.get('str'), '')
        self.assertEqual(fields.get('tail'), 42)


if __name__ == '__main__':
    unittest.main(verbosity=2)

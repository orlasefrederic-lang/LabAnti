# Отчёт о проверке NetMon 1.4 (`Netmon 1.4.zip`)

Проведена полная проверка кода версии **1.4** (`model.py`, `firewall.py`, `etw.py`, `winapi.py`, `monitor.py`, `storage.py`, `gui.py`, `fwgui.py`, `console.py`, `main.py`, `util.py`).
Все 100 штатных unit-тестов (`python3 -m unittest discover -s tests`) проходят, однако в логике жизненного цикла процессов (в том числе в новых механизмах версии 1.4), в управлении брандмауэром Windows, в разборе событий ETW и в интерфейсе обнаружен ряд ошибок.

В архив вместе с этим отчётом вложен скрипт **`test_netmon_1_4_bugs.py`** (15 автотестов `unittest`), который воспроизводит найденные ошибки на неизменённом коде NetMon 1.4 (`Ran 15 tests -> FAILED (failures=15)`).

---

## 1. [Высокая] `model.py`: Запоздавшее событие `on_process_start` прежнего владельца PID сливается с записью нового процесса (`_started_instance` / `_late_start`)

* **Где:** `model.py`, строки `404–449` (`_late_start`, `_started_instance`, `_apply_start`)
* **Суть ошибки:**
  В версии 1.4 метод `_started_instance(self, pid, ts)` ищет существующую запись процесса в `reversed(self._instances[pid])` (от самой новой к старой) и проверяет `_late_start(proc, ts)`.
  В `_late_start(proc, ts)` проверяется `not self._seen_alive_before(proc, ts)` — то есть `proc.first_seen + eps >= ts`.
  Но для **любого более нового** экземпляра `proc` с тем же PID (созданного позже по трафику или снимку процессов, у которого ещё нет `started` и `etw_started`) его `proc.first_seen` заведомо **больше** старого `ts` (`5.0 > 0.9`), поэтому `_seen_alive_before(proc, ts)` возвращает `False`, а `_late_start(proc, ts)` — **`True`**!
  При этом `_started_instance` не проверяет, существовал ли в `self._instances[pid]` **предыдущий** экземпляр (`instances[i - 1]`), который работал после момента `ts`.
* **К чему приводит (сценарий):**
  1. Первый процесс с PID 100 (`old.exe`) отправил пакет в `t = 1.0` (`first_seen = 1.0, started = None, etw_started = False`) и завершился в `t = 2.0` (`ended = 2.0`).
  2. Второй процесс с PID 100 (`new.exe`) запустился позже и отправил пакет в `t = 5.0` до прихода своего `on_process_start` (`first_seen = 5.0, started = None, etw_started = False`).
  3. Приходит задержавшийся `on_process_start(100, 0.9, 'C:\\old.exe')` первого процесса.
  4. `_started_instance(100, 0.9)` проверяет первым `new.exe`, видит `5.0 >= 0.9`, возвращает `new.exe` и:
     * перезаписывает `new.exe` именем и путём `old.exe` и временем запуска `started = 0.9`;
     * вызывает `_clamp_previous(new)`, который обрезает время завершения первой записи до `ended = 0.9` (раньше её собственного пакета `first_seen = 1.0`!);
     * когда следом приходит настоящий `on_process_start(100, 4.9, 'C:\\new.exe')`, запись с трафиком от `t = 5.0` закрывается временем `ended = 4.9`, а для `new.exe` создаётся третья пустая запись с `0` байт трафика.
* **Как исправить:**
  В `_started_instance` при обходе `instances = self._instances.get(pid, ())` с конца (`i` от `len(instances) - 1` до `0`), если `i > 0`, проверять предыдущий экземпляр `prev = instances[i - 1]`: `instances[i]` не мог запуститься раньше или во время жизни `prev` (т.е. если `prev` был жив после `ts`: `prev_alive = max(t for t in (prev.started, prev.last_seen, prev.ended if not prev.absent else None) if t is not None)` и `ts < prev_alive - eps`, то `instances[i]` нужно пропустить через `continue` и проверять более ранние экземпляры).

---

## 2. [Высокая] `model.py`: `_late_start` не сверяет имя/путь exe, а `_apply_start` при `cur.started is None` завершает работающий процесс старым событием запуска

* **Где:** `model.py`, строки `404–459` (`_late_start`, `_apply_start`)
* **Суть ошибки:**
  1. **Отсутствие сверки exe в `_late_start`:** В отличие от `_same_instance` (строки `692–715`), метод `_late_start` вообще не проверяет, совпадает ли `image` из `on_process_start(pid, ts, image)` с уже известным `proc.snap_name` или `proc.path`.
     * Если снимок `sync_processes` в `t = 5.0` увидел новый процесс `{100: ('new.exe', 1)}` (`proc.name = 'new.exe', proc.snap_name = 'new.exe'`), а затем дошло запоздавшее событие `on_process_start(100, 4.5, 'C:\\old.exe')` от предыдущего владельца PID 100, `_late_start` возвращает `True` и `_apply_start` перезаписывает `proc.name = 'old.exe'` и `proc.path = 'C:\\old.exe'`. Причём поскольку `proc.snap_name` остаётся `'new.exe'`, последующие снимки `sync_processes` считают, что PID не менялся, и работающий `new.exe` навсегда остаётся в таблице под именем `old.exe` (`C:\old.exe`).
  2. **Завершение текущего процесса событием из прошлого при `cur.started is None`:** В `_apply_start` (строки `450–457`):
     ```python
     cur = self.by_pid.get(pid)
     if cur is not None and cur.started is not None and ts < cur.started - (
             0.0 if cur.etw_started else CLOCK_EPS):
         return   # запоздавший запуск одного из прежних владельцев PID, записи о котором нет
     if cur is not None:
         self._end(cur, ts)
     ```
     Если у текущего процесса `cur` поле `cur.started` ещё равно `None` (запись создана по снимку или трафику в `t = 5.0`, а `fill_details` ещё не выполнился или не получил доступ к `GetProcessTimes`), то при приходе старого `on_process_start(100, 0.5, 'C:\\ancient.exe')`, который не подошёл ни к одному экземпляру в `_started_instance`, проверка `cur.started is not None` не срабатывает. В результате `self._end(cur, 0.5)` завершает работающий процесс `cur` временем из прошлого (`ended = 0.5 < first_seen = 5.0`) и ставит вместо него в `by_pid[100]` давно завершившийся `ancient.exe`.
* **Как исправить:**
  * Проверять совместимость пути и имени файла в `_late_start` (аналогично `_same_instance`).
  * В `_apply_start` проверять не только `cur.started`, но и `cur_alive = cur.started if cur.started is not None else cur.last_seen`: если `ts < cur_alive - (0.0 if (cur.etw_started or cur.seen_by_etw) else CLOCK_EPS)`, отбрасывать запоздавший запуск прежнего владельца (`return`).

---

## 3. [Высокая] `model.py`: Запоздавшее событие `on_process_stop` прежнего процесса ошибочно завершает новый процесс, если смена PID произошла быстрее `SLACK` (`0.25` с)

* **Где:** `model.py`, строки `461–473` (`_apply_stop`)
* **Суть ошибки:**
  ```python
    def _apply_stop(self, pid, ts):
        for proc in reversed(self._instances.get(pid, ())):
            if proc.started is not None and proc.started > ts:
                continue
            if proc.started is None and proc.first_seen > ts + SLACK:
                continue
            if proc.ended is None or ts < proc.ended:
                proc.ended = ts
                proc.conns = 0
                proc.dirty = True
            return
  ```
  Если `old.exe` (PID 100) завершился в `t = 100.01`, его PID сразу достался `new.exe`, и снимок `sync_processes` в `now = 100.05` (разница `0.04` с `< SLACK = 0.25` с) обнаружил смену имени процесса:
  * `sync_processes` закрывает `old.exe` временем снимка (`old.ended = 100.05`) и создаёт `new.exe` (`new.started = None, new.first_seen = 100.05, new.ended = None`).
  * Следом из буфера ETW доходит `on_process_stop(100, 100.01)` от `old.exe`.
  * `_apply_stop` проверяет первым `new.exe`: у него `started is None`, а `first_seen (100.05) > 100.01 + 0.25` ложно.
  * В итоге `_apply_stop` помечает **новый работающий процесс `new.exe`** как завершённый в `100.01` (`new.ended = 100.01`), а `old.exe` оставляет с неточным временем `100.05`.
  * Более того, из-за `new.ended is not None` метод `pending_details()` сразу сбрасывает `new.need_details = False` (у `new.exe` никогда не прочитаются путь, время запуска и командная строка), а `sync_processes` при следующих опросах считает его «зомби» (`not proc.absent`) и оставляет в статусе «завершена» навсегда.
* **Как исправить:**
  В `_apply_stop` при обходе `instances` с конца (`i` от `len(instances) - 1` до `0`), если `proc.started is None and proc.first_seen > ts` и при этом существует предыдущий экземпляр `prev = instances[i - 1]`, у которого `prev.ended is None or ts < prev.ended` (или `prev.ended >= proc.first_seen`), это событие остановки относится к `prev`, а не к `proc` (`continue`).

---

## 4. [Средняя] `model.py`: Порядок обработки пачки событий в `process_pending()` и потеря `min/max` времени пакетов в `on_traffic()`

* **Где:** `model.py`, строки `211–287` (`on_traffic`, `_push`, `process_pending`)
* **Суть ошибки:**
  1. **Инверсия `t0`/`t1` при приходе пакетов не по порядку (`on_traffic`, строки `225–233`):**
     При накоплении пакетов одного потока `a[5] = ts` присваивается безусловно, а `a[4]` никогда не обновляется. Если после пакета с `ts = 20.0` из другого буфера ETW пришёл пакет того же потока с `ts = 5.0`, получается `t0 = 10.0, t1 = 5.0`: минимальное время первого пакета (`5.0`) теряется, а `ep.last` не обновляется.
  2. **Приписывание трафика нового процесса старому внутри одной пачки `process_pending()`:**
     События сетевого стека (`Microsoft-Windows-Kernel-Network`) и события процессов (`Microsoft-Windows-Kernel-Process`) приходят из разных провайдеров ETW. Если за интервал `0.5` с между вызовами `process_pending()` сначала в `on_traffic` попали пакеты старого процесса (`ts = 10.0`) и нового процесса на том же PID (`ts = 15.0`), а чуть позже (до `process_pending()`) пришли `on_process_stop(pid, 11.0)` и `on_process_start(pid, 12.0, 'C:\\new.exe')`:
     * `_push` помещает `('traffic', self._acc)` в `self._queue` **перед** `('stop', ...)` и `('start', ...)`;
     * в `process_pending()` `_apply_traffic` выполняется **до** `_apply_stop(11.0)` и `_apply_start(12.0)`, когда модель ещё не знает, что первый процесс завершился в `11.0`, а в `12.0` запустился новый;
     * в результате пакет нового процесса (`ts = 15.0`) целиком записывается старому процессу (`old.exe`), а `new.exe` остаётся с `0` байт.
* **Как исправить:**
  * В `on_traffic` обновлять `a[4] = min(a[4], ts)` и `a[5] = max(a[5], ts)`.
  * В `process_pending()` (или при разборе очереди событий) сначала применять события жизненного цикла процессов (`start`/`stop`), либо сортировать события пачки по их временным меткам `ts`, а при разделении накопленного трафика учитывать границы `start`/`stop`, пришедшие в той же пачке.

---

## 5. [Средняя] `model.py`: Пропуск быстрого опроса служб `svchost.exe` (`_want_services`) и потеря `accept_ports` / DNS-имён при загрузке истории (`load_history`)

* **Где:** `model.py`, строки `315–316`, `442`, `608–609`, `662–673`, `747–749`, `785–796`
* **Суть ошибки:**
  1. **`_want_services` выставляется только в `_new_proc`:** Если процесс `svchost.exe` впервые обнаружен по сетевому событию (`_proc_at` -> `_new_proc(pid, ts)`), когда его ещё нет в `snap_names`, он создаётся с именем `'PID <N>'` и `_want_services` остаётся `False`. Когда чуть позже его настоящее имя `'svchost.exe'` устанавливается в `fill_details` (строка `749`), `sync_processes` (строка `609`) или в `_apply_start` при слиянии (строка `442`), флаг `self._want_services = True` нигде не выставляется — и список служб для этого `svchost.exe` не запрашивается до следующего 30-секундного цикла `SERVICES_EVERY`.
  2. **Затирание остановившихся служб в `set_services` (строка `669`):** `EnumServicesStatusExW` возвращает только `SERVICE_ACTIVE`. Если внутри общего процесса `svchost.exe` (например, `netsvcs`) служба `wuauserv` скачала обновление и остановилась, а `BITS` продолжает работать в том же PID, следующий вызов `set_services` перезаписывает `proc.services` с `'BITS, wuauserv'` на `'BITS'`, стирая `wuauserv` из истории и из сопоставления с правилами брандмауэра.
  3. **Потеря `accept_ports` и `dns_hosts` в `load_history` (строки `785–796`):** При загрузке истории из SQLite для входящих TCP-адресатов (`ep.inbound and ep.proto == 'TCP'`) локальный порт `ep.port` не добавляется в `proc.accept_ports`, а `ep.host` не добавляется в `self.dns_hosts`. После перезапуска монитора и продолжения записи процесса (`_reattach`), если слушающий сокет уже закрыт (или принадлежит родителю), новые пакеты этого же входящего TCP-соединения классифицируются методом `_is_inbound` как исходящие (`inbound = False`), создавая дублирующий исходящий адресат на эфемерный порт клиента.

---

## 6. [Высокая] `console.py`: Вызов `os.path.abspath` в Windows (`os.name == 'nt'`) ломает валидацию путей и переменные окружения в `--block` / `--unblock`

* **Где:** `console.py`, строки `146–170` (`run_firewall_cli`)
* **Суть ошибки:**
  ```python
  if args.block:
      path = os.path.abspath(args.block) if os.name == 'nt' else args.block
      error = check_blockable(path, services)
  ```
  На Linux (где гоняются тесты) `os.name != 'nt'`, поэтому `os.path.abspath` не вызывается. Но в **Windows** (`os.name == 'nt'`):
  1. Если пользователь передал относительное имя файла (например, `python main.py --block explorer.exe`), `os.path.abspath('explorer.exe')` молча превращает его в `C:\<текущая_папка>\explorer.exe` **до** вызова `check_blockable(path, services)`. В результате проверка `check_blockable` на полный путь полностью обходится, создаётся правило блокировки для несуществующего файла в текущей папке, а программа рапортует `Запрещено: C:\...\explorer.exe`, оставляя настоящий `C:\Windows\explorer.exe` без блокировки.
  2. Если пользователь передал путь с переменной окружения (например, `--block "%SystemRoot%\System32\svchost.exe" --service wuauserv` или `--unblock "%SystemRoot%\explorer.exe"`), `ntpath.abspath` в Windows считает строку `%SystemRoot%\...` относительным путём и приклеивает спереди текущую папку: `C:\<текущая_папка>\%SystemRoot%\explorer.exe`. После раскрытия переменной в `normalize_path` получается невалидный путь `c:\...\c:\windows\explorer.exe`.
  3. В строке `146` разбор `--service` использует `item.replace(';', ',').split(',')` вместо `firewall.split_services()`, поэтому службы, перечисленные через пробел, не разделяются.

---

## 7. [Высокая] `firewall.py`: `check_blockable` разрешает блокировку `ntoskrnl.exe` без `pid=4`, отвергает `%SystemRoot%`, а `block_plan` не очищает путь для PowerShell

* **Где:** `firewall.py`, строки `85–99` (`block_plan`) и `136–149` (`check_blockable`)
* **Суть ошибки:**
  1. **Обход защиты ядра (`ntoskrnl.exe`) при `pid=None`:**
     В `winapi.py:333` процессу `System` (PID 4) назначается путь `C:\Windows\System32\ntoskrnl.exe`.
     Однако `check_blockable(program, services, pid=None)` проверяет только:
     `if pid in (0, 4) or (program or '').strip().lower() == 'system':`
     Во всех местах, кроме таблицы процессов GUI, `pid` равен `None`: в `apply_block()` (`firewall.py:198`), в CLI `--block` (`console.py:151`) и в `BlockDialog` при вводе пути вручную или выборе через кнопку «Обзор…» (`fwgui.py:232`). Поэтому `check_blockable(r'C:\Windows\System32\ntoskrnl.exe', [])` возвращает `None` и позволяет заблокировать ядро Windows `ntoskrnl.exe`.
  2. **Отклонение путей вида `%SystemRoot%\...` и неполная проверка `ntpath.isabs`:**
     `check_blockable` вызывает `ntpath.isabs(program.strip().strip('"'))` **до** раскрытия переменных окружения (`%SystemRoot%` и т.п.), хотя `normalize_path` их поддерживает. Кроме того, в Python 3.8–3.10 (заявленных в требованиях `README.md`) `ntpath.isabs(r'\Windows\explorer.exe')` без буквы диска возвращает `True`, хотя брандмауэр Windows такие пути не принимает.
  3. **Неочищенный путь в `block_plan`:**
     Если путь содержит внешние кавычки, пробелы или прямые слеши (`"C:/Windows/explorer.exe"`), `normalize_path` (используемый в `rule_id`, `_rule_matches`, `verify_block` и `FirewallManager.status`) приводит его к `c:\windows\explorer.exe`, но `block_plan` записывает в `item['program']` исходную строку без очистки и передаёт её в `New-NetFirewallRule -Program`. В итоге `verify_block` подтверждает создание правила, интерфейс показывает «запрещена», но фильтр WFP в Windows не срабатывает на процесс.

---

## 8. [Средняя] `firewall.py` и `fwgui.py`: Неверные статусы брандмауэра для служб `svchost.exe` и при сбое начального чтения правил

* **Где:** `firewall.py`, строки `665–692` (`FirewallManager.status`), и `fwgui.py`, строки `52`, `109–115`, `147–151`
* **Суть ошибки:**
  1. **Пустой статус для временно разрешённых и частично запрещённых служб `svchost.exe` (`firewall.py:685–692`):**
     Для обычных программ (`whole`) метод `FirewallManager.status` обрабатывает все три состояния `whole.enabled`: `True` -> `('blocked', ...)`, `False` -> `('allowed', 'запрет выключен')`, `None` -> `('partial', 'частично')`.
     Но для служб `svchost.exe` проверяется только строгое равенство `enabled is True`:
     ```python
     blocked = [s for s in services
                if getattr(index.get((path, s.lower())), 'enabled', None) is True]
     ```
     * Если запрет службы временно выключен кнопкой **«Временно разрешить»** (`enabled is False`), `status()` возвращает `('', '')` вместо `('allowed', 'запрет выключен')`.
     * Если у службы включено только одно из правил (например, исходящее правило включено, а входящее выключено в `wf.msc`, т.е. `enabled is None`), `status()` возвращает **`('', '')`** (пустую ячейку без красной подсветки), скрывая тот факт, что исходящий доступ службе заблокирован!
  2. **Пустой статус вместо `'неизвестно'` при ошибке первого чтения правил (`firewall.py:675`):**
     Строка `if keys & uncertain or (not known and any(k in index for k in keys)):` возвращает `('unknown', 'неизвестно')`, только если программа уже была в `self._index`. Если чтение правил PowerShell завершилось ошибкой при самом первом опросе после запуска (`state_known = False`, `self._index` пуст), для всех программ в таблице возвращается `('', '')` вместо `('unknown', 'неизвестно')`.
  3. **Блокировка кнопок на вкладке «Брандмауэр» при состоянии «неизвестно» (`fwgui.py:109–115, 147–151`):**
     Когда `manager.state_known == False`, таблица вкладки «Брандмауэр» показывает в колонке «Состояние» текст `неизвестно`, но `_update_buttons()` и `set_enabled()` опираются на устаревшее значение `e.enabled` из кэша, блокируя кнопку «Снова запретить» (если раньше было `e.enabled == True`) или «Временно разрешить» (если раньше было `e.enabled == False`). Кроме того, кнопка «Обновить» (`fwgui.py:52`) вызывает `self.manager.refresh` напрямую без `self.app.watch_firewall()`.

---

## 9. [Средняя] `etw.py`: Сбой разбора событий ETW (`decode_payload`), если поле с `PROPERTY_PARAM_LENGTH` имеет длину `0`

* **Где:** `etw.py`, строки `263–275` (`fixed_size`) и `380–420` (`decode_payload`)
* **Суть ошибки:**
  Когда свойство манифеста TDH имеет флаг `PROPERTY_PARAM_LENGTH`, его длина `length` берётся из предыдущего числового поля события (`_ref_value(values, prop.length)`). Если в конкретном событии эта длина равна **`0`** (пустой бинарный блок или пустая строка со счётчиком длины):
  * для `TDH_INTYPE_BINARY` функция `fixed_size` проверяет `if length:` (`0` ложно!) и возвращает `None`, из-за чего `decode_payload` (строка `419`: `if size is None: break`) **прекращает разбор события**, теряя все последующие поля;
  * для `TDH_INTYPE_UNICODESTRING` (строка `381`) и `TDH_INTYPE_ANSISTRING` (строка `392`) проверка `if length:` также оказывается ложной при `length == 0`, и `decode_payload` вместо пустой строки переходит в ветку `else:` (`_find_wnull` / `data.find(b'\x00')`), считывая байты следующих полей события вплоть до ближайшего нуля и **смещая все остальные поля события**.
* **Как исправить:**
  Проверять `has_length = bool((prop.flags & PROPERTY_PARAM_LENGTH) or prop.length)` (передавая `length` в `fixed_size` с проверкой `if length is not None and (has_length or length): return length`), а также проверять выход за границу буфера `off + 2 + blen > n` для `TDH_INTYPE_COUNTEDSTRING` и `end > n` для `TDH_INTYPE_SID`.

---

## 10. [Низкая] Прочие недочёты (`gui.py`, `monitor.py`, `console.py`)

1. **Поиск по адресатам не учитывает галочку «Не учитывать localhost» (`model.py:968–978`, `gui.py:306–312`):**
   `Model.uids_matching_endpoints(query)` ищет подстроку по всем `self._ep_index`, включая `127.0.0.1` и `::1`, даже когда включён фильтр «Не учитывать localhost» (`hide_lo = True`). Из-за этого при поиске `127.0.0.1` или `localhost` в верхней таблице остаются программы, у которых кроме localhost был внешний трафик, но при выборе такой программы нижняя таблица адресатов оказывается пустой (`показано 0 — по строке поиска`).
2. **Невалидный ключ кэша `_group_eps_cache` при смене фильтров (`gui.py:433–441`):**
   В `_group_endpoints` кэш уникальных адресатов группы проверяет только совпадение суммы `cached[0] != group.n_eps`. Если из-за переключения фильтра периода или поиска состав `group.uids` изменился, а сумма `group.n_eps` случайно осталась прежней, возвращается устаревшее число адресатов. В ключе кэша следует хранить `(tuple(group.uids), group.n_eps)`.
3. **Задержка обновления служб после «Очистить историю…» (`monitor.py:127–132`, `gui.py:760–769`):**
   При очистке истории в `Monitor._loop()` сбрасывается `next_snapshot = 0.0`, но не сбрасывается `self._services_at = 0.0`, а в `App._clear_history()` не очищается кэш поиска `self._ep_hits`. Из-за этого после очистки истории у процессов `svchost.exe` до 3 секунд отсутствуют имена служб и статус брандмауэра.
4. **Утечка памяти в `RateTracker` в консольном режиме (`console.py:40–52`):**
   В `run_console()` на каждом шаге вызывается `rates.update(v.uid, ...)`, но в отличие от `gui.py:346` никогда не вызывается `rates.forget_except(...)`, поэтому словарь `rates._hist` бесконечно накапливает `uid` всех завершившихся процессов.

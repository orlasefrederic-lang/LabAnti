#!/usr/bin/env python3
"""Воспроизведение и проверка ошибок, найденных в NetMon 1.5.

Каждый тест проверяет корректное (ожидаемое) поведение. На неисправленном
NetMon 1.5 все эти тесты падают (FAIL), наглядно демонстрируя соответствующую ошибку.

Запуск:
    python3 test_netmon_1_5_bugs.py
"""

import argparse
import contextlib
import io
import os
import socket
import struct
import sys
import unittest
from unittest import mock

# Автоматический поиск папки netmon 1.5
HERE = os.path.dirname(os.path.abspath(__file__))
for candidate in (
    HERE,
    os.path.join(HERE, 'netmon'),
    os.path.join(HERE, 'Lab-claude-exciting-rubin-7ydofi', 'netmon'),
    os.path.join(HERE, 'netmon_1_5', 'Lab-claude-exciting-rubin-7ydofi', 'netmon'),
):
    if os.path.isfile(os.path.join(candidate, 'model.py')):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
        break

import console  # noqa: E402
import etw  # noqa: E402
import firewall  # noqa: E402
from etw import Prop, decode_payload  # noqa: E402
from firewall import (  # noqa: E402
    DemoFirewall,
    FirewallError,
    FirewallManager,
    block_plan,
    check_blockable,
)
from model import Model  # noqa: E402

LOCAL = '192.168.1.5'
SVCHOST = r'C:\Windows\System32\svchost.exe'
EXPLORER = r'C:\Windows\explorer.exe'


def v4(ip):
    return socket.inet_aton(ip)


def port(n):
    return n.to_bytes(2, 'big')


def send_tcp(model, pid, remote, rport, lport, sent, ts, local=LOCAL):
    model.on_traffic(pid, 'TCP', True, sent, v4(remote), port(rport), v4(local), port(lport), ts)


class Bug01StolenStopEventAcrossInstancesTest(unittest.TestCase):
    """Ошибка 1 (НОВАЯ в 1.5 — model.py: _apply_stop / _clamp_previous / _early_stops):
    Если процесс p1 запустился в 10.0 и завершился в 11.0, а процесс p2 на том же PID
    запустился в 12.0 и завершился в 13.0, причём событие stop(13.0) от p2 пришло раньше
    start(12.0) от p2 и раньше stop(11.0) от p1:
    1) p1 забирает чужой stop(13.0) и помечает p1.end_exact = True;
    2) при приходе start(12.0) от p2 метод _clamp_previous не сдвигает p1.ended=13.0
       (так как p1.end_exact=True), оставляя перекрывающиеся времена жизни [10..13] и [12..None];
    3) p2 навсегда остаётся «работающим» (ended=None), а пришедший следом настоящий
       stop(11.0) от p1 отвергается.
    То же самое происходит, если stop(13.0) от p2 пришёл первым в _early_stops, а затем
    пришёл задержавшийся start(10.0) от p1, который через _take_early_stop крадёт stop(13.0).
    """

    def test_p1_does_not_keep_p2_stop_when_p2_starts_before_that_stop(self):
        m = Model()
        m.resolve_names = False
        m.on_process_start(100, 10.0, r'C:\p1.exe')
        m.on_process_stop(100, 13.0)              # stop от p2 пришёл раньше start(12.0) и stop(11.0)
        m.on_process_start(100, 12.0, r'C:\p2.exe')
        m.on_process_stop(100, 11.0)
        m.process_pending()

        by_name = {p.name: p for p in m.procs.values()}
        self.assertEqual((by_name['p1.exe'].started, by_name['p1.exe'].ended), (10.0, 11.0))
        self.assertEqual((by_name['p2.exe'].started, by_name['p2.exe'].ended), (12.0, 13.0))

    def test_early_stop_of_p2_stolen_by_late_start_of_p1(self):
        m = Model()
        m.resolve_names = False
        m.on_process_stop(100, 13.0)              # stop от p2 попал в _early_stops
        m.on_process_start(100, 10.0, r'C:\p1.exe')
        m.on_process_stop(100, 11.0)
        m.on_process_start(100, 12.0, r'C:\p2.exe')
        m.process_pending()

        by_name = {p.name: p for p in m.procs.values()}
        self.assertEqual((by_name['p1.exe'].started, by_name['p1.exe'].ended), (10.0, 11.0))
        self.assertEqual((by_name['p2.exe'].started, by_name['p2.exe'].ended), (12.0, 13.0))


class Bug02HistoryContinuesToleranceTest(unittest.TestCase):
    """Ошибка 2 (НОВАЯ в 1.5 — model.py: _continues / SAME_CREATED = 0.001):
    2A. Для System (PID 4) и PID 0 время started вычисляется через
        boot_time() = time.time() - GetTickCount64() / 1000.0 (winapi.py:285, 333).
        Из-за шага GetTickCount64 (15.6 мс) и коррекции часов NTP два вызова boot_time()
        расходятся на 10–50+ мс (> SAME_CREATED = 1 мс), поэтому запись System (PID 4)
        из истории не продолжается при перезапуске монитора.
    2B. Если в прошлом сеансе процесс запустился при работающем мониторе и его started
        был записан из события ETW on_process_start (которое отстоит от CreateTime
        из GetProcessTimes на несколько миллисекунд — в пределах CLOCK_EPS / START_LAG),
        а в новом сеансе fill_details прочитал CreateTime из GetProcessTimes,
        разница (например, 10 мс = 0.01 с) превышает SAME_CREATED (0.001 с), и запись
        работающего процесса не продолжается.
    """

    def test_system_pid4_continues_with_boot_time_tick_jitter(self):
        rows = [{
            'id': 1, 'pid': 4, 'name': 'System',
            'path': r'C:\Windows\System32\ntoskrnl.exe', 'cmdline': '', 'services': '',
            'started': 1000.000, 'ended': None, 'first_seen': 1010.0, 'last_seen': 1050.0,
            'sent': 500, 'recv': 500, 'lo_sent': 0, 'lo_recv': 0, 'endpoints': [],
        }]
        m = Model()
        m.resolve_names = False
        m.load_history(rows)
        m.sync_processes({4: ('System', 0)}, now=1100.0)
        # При новом запуске boot_time() сдвинулся на один тик таймера Windows (15.6 мс)
        for uid, pid in m.pending_details():
            m.fill_details(uid, {
                'path': r'C:\Windows\System32\ntoskrnl.exe',
                'started': 1000.0156,
                'cmdline': '',
            }, now=1100.0)

        self.assertEqual(len(m.procs), 1, 'Запись System (PID 4) должна продолжаться, а не дублироваться')
        self.assertEqual(m.by_pid[4].sent, 500)

    def test_etw_started_history_record_continues_with_getprocesstimes_started(self):
        # В прошлом запуске процесс был создан по событию ETW on_process_start (ts=100.01),
        # а при следующем запуске монитора GetProcessTimes вернул CreateTime=100.00 (разница 10 мс)
        rows = [{
            'id': 1, 'pid': 50, 'name': 'app.exe',
            'path': r'C:\App\app.exe', 'cmdline': '', 'services': '',
            'started': 100.01, 'ended': None, 'first_seen': 100.01, 'last_seen': 105.0,
            'sent': 100, 'recv': 200, 'lo_sent': 0, 'lo_recv': 0, 'endpoints': [],
        }]
        m = Model()
        m.resolve_names = False
        m.load_history(rows)
        m.sync_processes({50: ('app.exe', 1)}, now=200.0)
        for uid, _pid in m.pending_details():
            m.fill_details(uid, {'path': r'C:\App\app.exe', 'started': 100.00}, now=200.0)

        self.assertEqual(len(m.procs), 1, 'Запись того же процесса (разница ETW/CreateTime 10 мс) должна продолжиться')
        self.assertEqual(m.by_pid[50].sent, 100)


class Bug03TrafficAndLifecycleBatchOrderingTest(unittest.TestCase):
    """Ошибка 3 (model.py: on_traffic / _push / process_pending):
    3A. В on_traffic при приходе пакетов одного потока не по порядку a[5] (t1)
        безусловно перезаписывается последним пришедшим ts, из-за чего t0 > t1.
    3B. Если пакеты старого (ts=10.0) и нового (ts=15.0) процесса с тем же PID
        пришли из Kernel-Network раньше, чем события stop(11.0) и start(12.0) из
        Kernel-Process в той же пачке process_pending(), весь трафик нового
        процесса приписывается старому (уже завершившемуся в 11.0).
    """

    def test_out_of_order_packets_preserve_min_first_and_max_last(self):
        m = Model()
        m.resolve_names = False
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=20, ts=20.0)
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=5, ts=5.0)
        m.process_pending()

        ep = m.by_pid[100].endpoints[('TCP', '1.1.1.1', 443, False)]
        self.assertEqual(ep.first, 5.0)
        self.assertEqual(ep.last, 20.0)

    def test_traffic_arriving_before_stop_and_start_in_same_batch(self):
        m = Model()
        m.resolve_names = False
        m.on_process_start(100, 1.0, r'C:\old.exe')
        send_tcp(m, 100, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        send_tcp(m, 100, '2.2.2.2', 443, 50001, sent=25, ts=15.0)
        m.on_process_stop(100, 11.0)
        m.on_process_start(100, 12.0, r'C:\new.exe')
        m.process_pending()

        by_name = {p.name: p for p in m.procs.values()}
        self.assertEqual(by_name['old.exe'].sent, 10)
        self.assertEqual(by_name['new.exe'].sent, 25)


class Bug04SvchostWantServicesAndHistoryRestoreTest(unittest.TestCase):
    """Ошибка 4 (model.py: _want_services / load_history):
    4A. Если запись svchost.exe сначала создана по трафику (с именем 'PID N'),
        а имя 'svchost.exe' узнаётся позже в sync_processes, fill_details или
        _apply_start, флаг _want_services не выставляется.
    4B. load_history не восстанавливает accept_ports для входящих TCP-адресатов,
        поэтому после перезапуска и _reattach новые пакеты принятого соединения
        (если слушающий сокет не в listen_table) считаются исходящими.
    """

    def test_want_services_is_set_when_svchost_name_is_discovered_later(self):
        m = Model()
        m.resolve_names = False
        send_tcp(m, 500, '1.1.1.1', 443, 50000, sent=10, ts=10.0)
        m.process_pending()
        self.assertFalse(m.want_services())
        m.fill_details(m.by_pid[500].uid, {'path': SVCHOST, 'started': 9.0}, now=10.5)
        self.assertTrue(m.want_services())

    def test_reattached_history_process_keeps_inbound_accept_port(self):
        rows = [{
            'id': 1, 'pid': 201, 'name': 'server.exe', 'path': r'C:\server.exe',
            'cmdline': '', 'services': '', 'started': 5.0, 'ended': None,
            'first_seen': 10.0, 'last_seen': 11.0, 'sent': 100, 'recv': 0,
            'lo_sent': 0, 'lo_recv': 0,
            'endpoints': [{
                'proc_id': 1, 'proto': 'TCP', 'ip': '10.0.0.8', 'port': 9000,
                'inbound': 1, 'host': '', 'sent': 100, 'recv': 0,
                'psent': 1, 'precv': 0, 'first_seen': 11.0, 'last_seen': 11.0,
            }],
        }]
        m2 = Model()
        m2.resolve_names = False
        m2.load_history(rows)
        m2.sync_processes({201: ('server.exe', 1)}, now=20.0)
        m2.sync_tcp([], now=20.0)
        for uid, _pid in m2.pending_details():
            m2.fill_details(uid, {'path': r'C:\server.exe', 'started': 5.0}, now=20.0)
        send_tcp(m2, 201, '10.0.0.8', 60000, 9000, sent=50, ts=21.0)
        m2.process_pending()

        eps = m2.by_pid[201].endpoints
        self.assertEqual(list(eps.keys()), [('TCP', '10.0.0.8', 9000, True)])


class Bug05ConsoleFirewallCliWindowsAbspathTest(unittest.TestCase):
    """Ошибка 5 (console.py: run_firewall_cli):
    В Windows (os.name == 'nt') вызов os.path.abspath(args.block) перед check_blockable
    превращает относительное имя 'explorer.exe' в 'C:\\текущая_папка\\explorer.exe',
    обходя проверку check_blockable, и ломает пути с '%SystemRoot%\\...'.
    """

    def test_relative_path_is_rejected_on_windows_cli(self):
        fw = DemoFirewall(delay=0)
        args = argparse.Namespace(
            block='explorer.exe', unblock=None, service=[], outbound_only=False, blocked=False
        )
        out = io.StringIO()
        with mock.patch.object(console.os, 'name', 'nt'), \
                mock.patch.object(console.os.path, 'abspath', lambda p: r'C:\work\\' + p), \
                contextlib.redirect_stdout(out):
            code = console.run_firewall_cli(fw, args)

        self.assertEqual(code, 1)
        self.assertEqual(fw.rules, {})


class Bug06CheckBlockableAndCleanPathTest(unittest.TestCase):
    """Ошибка 6 (firewall.py: check_blockable / block_plan):
    6A. check_blockable без pid=4 разрешает заблокировать C:\\Windows\\System32\\ntoskrnl.exe.
    6B. check_blockable отклоняет '%SystemRoot%\\explorer.exe' (ntpath.isabs до раскрытия переменных).
    6C. block_plan не очищает путь от внешних кавычек и прямых слешей '/'.
    """

    def test_ntoskrnl_is_rejected_even_without_pid(self):
        self.assertIsNotNone(check_blockable(r'C:\Windows\System32\ntoskrnl.exe', [], pid=None))

    def test_env_var_path_is_accepted_by_check_blockable(self):
        with mock.patch.dict(os.environ, {'SystemRoot': r'C:\Windows'}):
            self.assertIsNone(check_blockable(r'%SystemRoot%\explorer.exe', []))

    def test_block_plan_cleans_quotes_and_forward_slashes(self):
        plan = block_plan('  "C:/Windows/explorer.exe"  ')
        self.assertEqual(plan[0]['program'], r'C:\Windows\explorer.exe')


class Bug07FirewallManagerServiceStatusTest(unittest.TestCase):
    """Ошибка 7 (firewall.py: FirewallManager.status):
    7A. Для временно разрешённой службы svchost.exe (enabled=False) возвращается ('', '')
        вместо ('allowed', 'запрет выключен').
    7B. Для частично запрещённой службы (enabled=None, например исходящее правило включено,
        входящее выключено) возвращается ('', '') вместо статуса запрета.
    7C. При сбое первого чтения правил (state_known=False, _index пуст) возвращается ('', '')
        вместо ('unknown', 'неизвестно').
    """

    def test_paused_and_partially_enabled_service_status(self):
        firewall.log.disabled = True
        self.addCleanup(setattr, firewall.log, 'disabled', False)
        backend = DemoFirewall(delay=0)
        m = FirewallManager(backend)
        self.addCleanup(m.shutdown)

        m.block(SVCHOST, ['BITS']).result()
        m.set_enabled(m.entries, False).result()
        self.assertEqual(m.status(SVCHOST, 'BITS'), ('allowed', 'запрет выключен'))

        out_id = firewall.rule_id(SVCHOST, 'BITS', 'out')
        backend.set_enabled([out_id], True)
        m.refresh().result()
        state, _label = m.status(SVCHOST, 'BITS')
        self.assertIn(state, ('partial', 'blocked'))

    def test_initial_read_failure_reports_unknown_status(self):
        firewall.log.disabled = True
        self.addCleanup(setattr, firewall.log, 'disabled', False)
        backend = DemoFirewall(delay=0)
        backend.state = mock.Mock(side_effect=FirewallError('Отказано в доступе'))
        m = FirewallManager(backend)
        self.addCleanup(m.shutdown)

        m.refresh().result()
        self.assertEqual(m.status(EXPLORER), ('unknown', 'неизвестно'))


class Bug08EtwDecodeZeroParamLengthTest(unittest.TestCase):
    """Ошибка 8 (etw.py: decode_payload / fixed_size):
    Поле BINARY или UNICODESTRING/ANSISTRING с PROPERTY_PARAM_LENGTH и длиной 0
    прерывает разбор события или съедает следующие поля.
    """

    def test_zero_param_length_binary_and_string_do_not_break_decoding(self):
        U8, U16, UNICODE, BINARY = 4, 6, 1, 14
        props = [
            Prop('BlobLen', 0, U16, 0, 1, 0),
            Prop('Blob', etw.PROPERTY_PARAM_LENGTH, BINARY, 0, 1, 0),
            Prop('StrLen', 0, U16, 0, 1, 0),
            Prop('Str', etw.PROPERTY_PARAM_LENGTH, UNICODE, 0, 1, 2),
            Prop('Tail', 0, U8, 0, 1, 0),
        ]
        data = struct.pack('<HHB', 0, 0, 42)
        fields = decode_payload(props, data, 8)
        self.assertEqual(fields.get('blob'), b'')
        self.assertEqual(fields.get('str'), '')
        self.assertEqual(fields.get('tail'), 42)


if __name__ == '__main__':
    unittest.main(verbosity=2)

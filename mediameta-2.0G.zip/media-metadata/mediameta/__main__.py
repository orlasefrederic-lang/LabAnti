"""Entry point for ``python -m mediameta``."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
